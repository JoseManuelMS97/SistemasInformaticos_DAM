#!/bin/bash
#Nombre: Jose Manuel Monteagudo Sanchez
#Fecha: 26/02/2020
#Enunciado: Nos dice que animal somos segun horoscopo chino con array

array=("El Mono" "El Gallo" "El Perro" "El Cerdo" "La Rata" "El Buey" "El Tigre" "El Conejo" "El Dragon" "La Serpiente" "El Caballo" "La Cabra")

read -n 4 -p "En que año naciste? : " ANIO ; echo
RESTO=$[$ANIO%12]

echo "Si naciste en $ANIO te corresponde ${array[$RESTO]} "