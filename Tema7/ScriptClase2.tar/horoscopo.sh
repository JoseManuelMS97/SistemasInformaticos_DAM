#!/bin/bash
#Nombre: Jose Manuel Monteagudo Sanchez
#Fecha: 26/02/2020
#Enunciado: Nos dice que animal somos segun horoscopo chino

read -n 4 -p "En que año naciste? : " ANIO ; echo
RESTO=$[ANIO%12]
case $RESTO in
		0) 
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		1)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		2)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		3)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		4)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		5)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		6)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		7)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		8)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		9)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		10)
		echo "Si naciste en $ANIO  te corresponde El Mono según el horóscopo chino.";;
		11)
		echo "Si naciste en $ANIO te corresponde El Mono según el horóscopo chino.";;
		*)
		echo "Dato invalido";;
esac
